$('#target').on('mouseover', function(){
  $('#target').addClass('highlighted')
})
$('#target').on('mouseleave', function(){
  $('#target').removeClass('highlighted')
})
