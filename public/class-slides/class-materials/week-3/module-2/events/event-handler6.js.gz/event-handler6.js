$('button#go').on('click', function(){
  $('#output').text( $('input#color').val() )
})