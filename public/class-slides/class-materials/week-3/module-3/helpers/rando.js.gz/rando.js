var rand = Math.floor( Math.random() * words.length )
words[rand]