var word = "Hello"

word[0]
word[1]
word[4]
word[5]

var index = 3
word[index]

// strings have a length property
var len = word.length
word[len]
word[len - 1]