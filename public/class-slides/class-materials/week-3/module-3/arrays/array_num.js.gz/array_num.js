var nums = [5, 10, 20, 50, 100, 250]

nums[0]
nums[1]
nums[5]
nums[6]

var index = 4
nums[index]

var len = nums.length
nums[len]
nums[len - 1]