var words = ["Hello", "and", "welcome", "to", "my", "webpage!"]

words[0]
words[1]
words[5]
words[6]

var the_number_three = 3
words[the_number_three]

var len = words.length
words[len]
words[len - 1]