var str = "one two three"
var arr = str.split(' ')
var new_str = arr.join(' and a ')

// now our turn...
var scrambled_poem = "roses red are bacon crispy i bacon love and is blue violets are"