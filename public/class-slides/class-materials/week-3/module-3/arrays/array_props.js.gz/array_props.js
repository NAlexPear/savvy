var arr = ['stuff', 'more stuff', 'even more stuff']

arr.length

arr.push("More on the end!!!")
var lastItem = words.pop()

arr.unshift("More at the beginning!!")
var firstItem = words.shift()