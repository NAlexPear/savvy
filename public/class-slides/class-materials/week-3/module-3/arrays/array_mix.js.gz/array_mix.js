var all_kinds_of_stuff = ["Hello", 3, undefined, true, ["woah", "dude"], null]

all_kinds_of_stuff[0]
all_kinds_of_stuff[1]
all_kinds_of_stuff[5]
all_kinds_of_stuff[6]

var another_array = all_kinds_of_stuff[4]

// ?
another_array[0]

// ?
all_kinds_of_stuff[4][1]