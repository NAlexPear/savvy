var greeting = "Hello and welcome to my webpage!"

greeting[0]
greeting[1]
greeting[28]
greeting[29]

var index = 2
greeting[index]

var len = greeting.length
greeting[len]
greeting[len - 1]