var hello_while = function () {
  var i = 0;

  while (i<=50){
    console.log(i);
    i+=2;
  }
}
