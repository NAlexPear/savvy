// Figure out what each of the following does:

Math
Math.PI
Math.E
Math.pow(9, 2)
Math.random()
Math.floor(7.2)
Math.ceil(7.2)
Math.ceil( Math.random() * 10 )
Math.ceil( Math.random() * 10 )

// How about?

parseInt("23")
parseInt(23)
parseInt("boink")
