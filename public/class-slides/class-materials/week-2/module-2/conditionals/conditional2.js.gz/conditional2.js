var hero, bad_guy

if (hero === 'strong') {
  if (bad_guy === 'weak') {
    console.log('Ah-ha, an easy vicotry!');
  }
  console.log('Let us battle to the death.');
}
