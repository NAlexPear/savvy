$('h1').show() //convenience method to set element's 'display' property to 'block'
$('p#secret').hide() //set element's 'display' property to 'none'
$('ol li').fadeIn() // fade in a set of matched elements over time
$('p .comments').fadeOut() // fade out as set of matched elements over time
$('div#thing').slideDown() // animate an element sliding down over time
$('#message').slideUp() // animate an element sliding up over time
$('.alert').slideToggle() // toggle between an element sliding up or down over time depending on whether it's visible or not
